#!/usr/bin/env python3
# Your full script will be placed here. 
# (Due to notebook limitations, place the actual script content manually if needed.)
